<h2>Hey there, Friend!</h2>
<p>This Project is about a basket-app that made with React.js</p>
<h3>What is actually this Project and How it works??</h3>
<p>
  First: Download the zip file and extract that in a folder
  <br />
  Second: Open the final_project folder in VS Code
  <br />
  Third: Install node_modules folder uding $npm i node_modules (For running commands using npm)
   <br />
  Fourth: Use Terminal (That's like cmd) to run the Project using $npm start (Your Project will run as a test; So you can customize that as you want and etc..) Terminal ShortCut is: Ctrl + ~
   <br />
  Notice: If you wanna upload this React Project, You should rent a host and do one of this things:
   <br />
  1 - If you need, you can run this command $npm run build ,and then upload the build folder in your host
   <br />
  Or
   <br />
  2- Upload the Project folder on your host without node_modules folder
   <br />
  GOOD LUCK!
</p>
