export const SET_PRODUCTS = "SET_PRODUCTS";
