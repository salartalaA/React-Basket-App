import { SET_PRODUCTS } from "./actionType";

const products = [
  {
    id: 1,
    name: "قهوه اول",
    describe: "توضیحات قهوه ی اول",
    image:
      "https://28coffee.ir/wp-content/uploads/2023/02/SUNRISE-100-ROBUSTA-250G-185x185.webp",
    price: 200,
  },
  {
    id: 2,
    name: "قهوه دوم",
    describe: "توضیحات قهوه ی دوم",
    image:
      "https://28coffee.ir/wp-content/uploads/2023/02/rhino-40-arabica-250g-185x185.webp",
    price: 150,
  },
];

export const getProducts = () => {
  return {
    type: SET_PRODUCTS,
    payload: products,
  };
};
