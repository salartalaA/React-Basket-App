import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { getProducts } from "../redux/products/action";
import { addToCart, decrement, increment } from "../redux/cart/action";
import Swal from "sweetalert2";

const ShowProduct = () => {
  const { id } = useParams(); // Get the product ID from the URL
  const { products, loading, error } = useSelector((state) => state.product);
  const cart = useSelector((state) => state.shoppingCart.cart);
  const dispatch = useDispatch();
  const [selectedWeight, setSelectedWeight] = useState("");
  const [selectedEqs, setSelectedEqs] = useState(""); // State for selected eqs option
  const [isButtonDisabled, setIsButtonDisabled] = useState(true);

  useEffect(() => {
    dispatch(getProducts());
  }, [dispatch]);

  useEffect(() => {
    // Disable the button if either selectedWeight or selectedEqs is empty
    setIsButtonDisabled(!(selectedWeight && selectedEqs));
  }, [selectedWeight, selectedEqs]);

  const handleAddToCart = (selectedProduct) => {
    dispatch(
      addToCart({
        ...selectedProduct,
        weight: selectedWeight,
        eqs: selectedEqs,
      })
    );
    Swal.fire({
      title: "محصول به سبد خرید اضافه شد",
      icon: "success",
      showConfirmButton: false,
      timerProgressBar: true,
      timer: 2000,
      toast: true,
      position: "top",
    });
  };

  const handleWeightClick = (weight) => {
    setSelectedWeight(weight);
  };

  const handleEqsChange = (event) => {
    setSelectedEqs(event.target.value);
  };

  const handleIncrement = (selectedProductId) => {
    dispatch(increment(selectedProductId));
    Swal.fire({
      title: "یک واحد به تعداد محصول اضافه شد",
      icon: "success",
      showConfirmButton: false,
      timerProgressBar: true,
      timer: 2000,
      toast: true,
      position: "top",
    });
  };

  const handleDecrement = (selectedProductId) => {
    dispatch(decrement(selectedProductId));
    Swal.fire({
      title: "یک واحد از تعداد محصول کم شد",
      icon: "success",
      showConfirmButton: false,
      timerProgressBar: true,
      timer: 2000,
      toast: true,
      position: "top",
    });
  };

  // Wait for products to load or handle loading state
  if (loading) {
    return <h2>Loading...</h2>;
  }

  // Handle error state
  if (error) {
    return <h2>Error loading products: {error}</h2>;
  }

  // Handle case where products are empty or undefined
  if (!products || products.length === 0) {
    return <h2>Products not available</h2>;
  }

  // Find the selected product by ID
  const selectedProduct = products.find(
    (product) => product.id === parseInt(id)
  );

  // Get the quantity of the selected product from the cart
  const cartItem = cart.find((item) => item.id === selectedProduct?.id);
  const selectedProductQty = cartItem ? cartItem.qty : 0;

  // Handle case where selected product is not found
  if (!selectedProduct) {
    return <h2>Product not found</h2>;
  }

  return (
    <div className="container mx-auto p-4">
      <div className="mt-10">
        <div className="flex flex-col lg:flex-row lg:space-x-12 lg:space-x-reverse space-y-6 lg:space-y-0">
          <div key={selectedProduct.id} className="flex-1">
            <div className="min-w-72">
              <div className="bg-cyan-300 rounded-t-xl">
                <img
                  src={selectedProduct.image}
                  alt={selectedProduct.name}
                  className="w-full rounded-t-xl"
                />
              </div>
              <div className="bg-blue-700 text-white h-auto mb-10 p-4 rounded-b-xl">
                <div>
                  <span className="font-bold">
                    {selectedProduct.price} تومان
                  </span>
                </div>
                <div>
                  <span className="font-light">{selectedProduct.name}</span>
                </div>
                <div>
                  <p>{selectedProduct.description}</p>
                </div>
              </div>
            </div>
          </div>
          <div className="flex-1 bg-yellow-400 rounded-3xl p-4 lg:p-12">
            <div className="my-6">
              <h2 className="text-lg text-center mb-4 font-bold">
                وزن بسته بندی
              </h2>
              <div className="flex justify-center space-x-4 space-x-reverse text-white">
                {["250", "500", "700"].map((weight) => (
                  <div
                    key={weight}
                    onClick={() => handleWeightClick(weight)}
                    id={weight}
                    className={`bg-red-600 p-2 rounded-xl cursor-pointer ${
                      selectedWeight === weight ? "selected" : ""
                    }`}
                  >
                    {weight} گرم
                  </div>
                ))}
              </div>
            </div>
            <div className="my-6">
              <h2 className="text-lg font-bold">تجهیزات</h2>
              <select
                className="w-full border-2 border-blue-300 p-1 rounded-xl cursor-pointer"
                value={selectedEqs}
                onChange={handleEqsChange}
              >
                <option value="">یک گزینه را انتخاب کنید</option>
                <option value="اسپرسو خانگی">اسپرسو خانگی</option>
                <option value="نیمه صنعتی">نیمه صنعتی</option>
                <option value="تجاری">تجاری</option>
              </select>
            </div>
            <div className="my-6">
              <button
                onClick={() => handleAddToCart(selectedProduct)}
                className={`w-full mb-4 border-1 rounded-xl p-2 text-white cursor-pointer ${
                  isButtonDisabled ? "bg-gray-700" : "bg-black"
                }`}
                disabled={isButtonDisabled}
              >
                افزودن به سبد خرید
              </button>
              <div className="flex justify-between items-center">
                <button
                  onClick={() => handleIncrement(selectedProduct.id)}
                  className="font-bold border-1 bg-black w-24 text-white rounded-xl"
                >
                  +
                </button>
                <span className="text-center">
                  تعداد آیتم ها: {selectedProductQty}
                </span>
                <button
                  onClick={() => handleDecrement(selectedProduct.id)}
                  className="font-bold border-1 bg-black w-24 text-white rounded-xl"
                >
                  -
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShowProduct;
