import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { getProducts } from "../redux/products/action";
import { addToCart, decrement, increment } from "../redux/cart/action";
import Swal from "sweetalert2";

const ShowProduct = () => {
  const { id } = useParams(); // Get the product ID from the URL
  const { products, loading, error } = useSelector((state) => state.product);
  const cart = useSelector((state) => state.shoppingCart.cart);
  const dispatch = useDispatch();
  const [selectedWeight, setSelectedWeight] = useState("");
  const [selectedEqs, setSelectedEqs] = useState(""); // State for selected eqs option
  const [isButtonDisabled, setIsButtonDisabled] = useState(true);

  useEffect(() => {
    dispatch(getProducts());
  }, [dispatch]);

  useEffect(() => {
    // Disable the button if either selectedWeight or selectedEqs is empty
    setIsButtonDisabled(!(selectedWeight && selectedEqs));
  }, [selectedWeight, selectedEqs]);

  const handleAddToCart = (selectedProduct) => {
    dispatch(
      addToCart({
        ...selectedProduct,
        weight: selectedWeight,
        eqs: selectedEqs,
      })
    );
    Swal.fire({
      title: "محصول به سبد خرید اضافه شد",
      icon: "success",
      showConfirmButton: false,
      timerProgressBar: true,
      timer: 2000,
      toast: true,
      position: "top",
    });
  };

  const handleWeightClick = (weight) => {
    setSelectedWeight(weight);
  };

  const handleEqsChange = (event) => {
    setSelectedEqs(event.target.value);
  };

  const handleIncrement = (selectedProductId) => {
    dispatch(increment(selectedProductId));
    Swal.fire({
      title: "یک واحد به تعداد محصول اضافه شد",
      icon: "success",
      showConfirmButton: false,
      timerProgressBar: true,
      timer: 2000,
      toast: true,
      position: "top",
    });
  };

  const handleDecrement = (selectedProductId) => {
    dispatch(decrement(selectedProductId));
    Swal.fire({
      title: "یک واحد از تعداد محصول کم شد",
      icon: "success",
      showConfirmButton: false,
      timerProgressBar: true,
      timer: 2000,
      toast: true,
      position: "top",
    });
  };

  // Wait for products to load or handle loading state
  if (loading) {
    return <h2>Loading...</h2>;
  }

  // Handle error state
  if (error) {
    return <h2>Error loading products: {error}</h2>;
  }

  // Handle case where products are empty or undefined
  if (!products || products.length === 0) {
    return <h2>Products not available</h2>;
  }

  // Find the selected product by ID
  const selectedProduct = products.find(
    (product) => product.id === parseInt(id)
  );

  // Get the quantity of the selected product from the cart
  const cartItem = cart.find((item) => item.id === selectedProduct?.id);
  const selectedProductQty = cartItem ? cartItem.qty : 0;

  // Handle case where selected product is not found
  if (!selectedProduct) {
    return <h2>Product not found</h2>;
  }

  return (
    <div className="container">
      <div className="mt-10">
        <div className="flex space-x-12 space-x-reverse">
          <div key={selectedProduct.id}>
            <div className="min-w-72">
              <div className="bg-cyan-300 rounded-t-xl">
                <img
                  src={selectedProduct.image}
                  alt={selectedProduct.name}
                  className="w-72 rounded-t-xl"
                />
              </div>
              <div className="bg-indigo-700 text-white h-auto mb-10 p-4 rounded-b-xl">
                <div>
                  <span className="font-bold">
                    {selectedProduct.price} تومان
                  </span>
                </div>
                <div>
                  <span className="font-light">{selectedProduct.name}</span>
                </div>
                <div>
                  <p>{selectedProduct.description}</p>
                </div>
              </div>
            </div>
          </div>
          <div className="w-full bg-sky-200">
            <div className="m-12">
              <div className="flex my-6">
                <h2 className="text-lg font-bold">وزن بسته بندی</h2>
                <div className="flex space-x-12 space-x-reverse mx-12 text-white">
                  {["250", "500", "700"].map((weight) => (
                    <div
                      key={weight}
                      onClick={() => handleWeightClick(weight)}
                      id={weight}
                      className={`bg-blue-600 p-2 rounded-xl cursor-pointer ${
                        selectedWeight === weight ? "selected" : ""
                      }`}
                    >
                      {weight} گرم
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex my-6">
                <h2 className="text-lg font-bold">تجهیزات</h2>
                <select
                  className="mx-6 border-2 border-blue-300 p-1 rounded-xl"
                  value={selectedEqs}
                  onChange={handleEqsChange}
                >
                  <option value="">یک گزینه را انتخاب کنید</option>
                  <option value="اسپرسو خانگی">اسپرسو خانگی</option>
                  <option value="نیمه صنعتی">نیمه صنعتی</option>
                  <option value="تجاری">تجاری</option>
                </select>
              </div>

              <div className="flex">
                <button
                  onClick={() => handleAddToCart(selectedProduct)}
                  className={`m-6 border-1 rounded-xl p-2 text-white ${
                    isButtonDisabled ? "bg-gray-700" : "bg-black"
                  }`}
                  disabled={isButtonDisabled}
                >
                  افزودن به سبد خرید
                </button>
                <div className="mt-8">
                  <button
                    onClick={() => handleIncrement(selectedProduct.id)}
                    className="font-bold border-1 bg-black mx-6 w-24 text-white rounded-xl"
                  >
                    +
                  </button>
                  <button
                    onClick={() => handleDecrement(selectedProduct.id)}
                    className="font-bold border-1 bg-black mx-6 w-24 text-white rounded-xl"
                  >
                    -
                  </button>
                </div>
              </div>

              <div>تعداد آیتم ها: {selectedProductQty}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShowProduct;
