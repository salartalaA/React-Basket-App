import { useDispatch, useSelector } from "react-redux";
import Swal from "sweetalert2";
import { clearCart, removeFromCart } from "../redux/cart/action";
import { Link } from "react-router-dom";

const ShoppingCart = () => {
  const { cart } = useSelector((state) => state.shoppingCart);
  const dispatch = useDispatch();

  const handleRemoveFromCart = (selectedProductId) => {
    dispatch(removeFromCart(selectedProductId));
    Swal.fire({
      title: "محصول از سبد خرید حذف شد",
      icon: "warning",
      showConfirmButton: false,
      timerProgressBar: true,
      timer: 2000,
      toast: true,
      position: "top",
    });
  };

  const handleClearCart = () => {
    dispatch(clearCart());
    Swal.fire({
      title: "سبد خرید خالی شد",
      icon: "warning",
      showConfirmButton: false,
      timerProgressBar: true,
      timer: 3000,
      toast: true,
      position: "top",
    });
  };

  return (
    <div className="container mx-auto p-4">
      {cart.length === 0 ? (
        <div className="text-center mt-10">
          <h2 className="font-bold text-xl text-blue-600">
            سبد خرید شما در حال حاضر خالی است
          </h2>
          <div className="mt-8">
            <Link className="bg-black text-white p-2 rounded-xl" to="/products">
              بازگشت به فروشگاه
            </Link>
          </div>
        </div>
      ) : (
        <div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
            {cart.map((product) => (
              <div
                key={product.id}
                className="bg-gray-100 rounded-xl shadow-md overflow-hidden"
              >
                <div className="bg-amber-400 p-4">
                  <img
                    className="w-full h-48 object-cover"
                    src={product.image}
                    alt={product.name}
                  />
                </div>
                <div className="p-4 space-y-2">
                  <div className="bg-purple-500 text-white p-2 rounded">
                    نام محصول: {product.name}
                  </div>
                  <div className="bg-indigo-600 text-white p-2 rounded">
                    قیمت محصول: {product.price} تومان
                  </div>
                  <div className="bg-green-500 text-white p-2 rounded">
                    وزن محصول: {product.weight} گرم
                  </div>
                  <div className="bg-pink-600 text-white p-2 rounded">
                    اسباب محصول: {product.eqs}
                  </div>
                  <div className="bg-black text-white p-2 rounded">
                    تعداد محصول: {product.qty} عدد
                  </div>
                </div>
                <div className="text-center p-4">
                  <button
                    onClick={() => handleRemoveFromCart(product.id)}
                    className="bg-red-600 p-3 rounded-xl text-white font-bold w-full"
                  >
                    حذف محصول
                  </button>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6">
            <div className="bg-blue-700 text-white text-center p-4 rounded-xl mb-6">
              قیمت کل:{" "}
              {cart.reduce(
                (total, product) => total + product.price * product.qty,
                0
              )}{" "}
              تومان
            </div>
            <div className="text-center">
              <button
                onClick={handleClearCart}
                className="bg-black font-bold text-white p-3 rounded-xl w-full md:w-auto"
              >
                حذف سبد خرید
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ShoppingCart;
