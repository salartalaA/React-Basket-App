import { useDispatch, useSelector } from "react-redux";
import Swal from "sweetalert2";
import { clearCart, removeFromCart } from "../redux/cart/action";
import { Link } from "react-router-dom";

const ShoppingCart = () => {
  const { cart } = useSelector((state) => state.shoppingCart);
  const dispatch = useDispatch();

  const handleRemoveFromCart = (selectedProductId) => {
    dispatch(removeFromCart(selectedProductId));
    Swal.fire({
      title: "محصول از سبد خرید حذف شد",
      icon: "warning",
      showConfirmButton: false,
      timerProgressBar: true,
      timer: 2000,
      toast: true,
      position: "top",
    });
  };
  const handleClearCart = () => {
    dispatch(clearCart());
    Swal.fire({
      title: "سبد خرید خالی شد",
      icon: "warning",
      showConfirmButton: false,
      timerProgressBar: true,
      timer: 3000,
      toast: true,
      position: "top",
    });
  };
  return (
    <>
      {cart.length === 0 ? (
        <div>
          <h2 className="text-center font-bold mt-10 text-xl text-blue-600">
            سبد خرید شما در حال حاضر خالی است
          </h2>
          <div className="text-center mt-8 text-white">
            <Link className="bg-black p-2 rounded-xl" to="/products">
              بازگشت به فروشگاه
            </Link>
          </div>
        </div>
      ) : (
        <div className="container mt-6">
          {cart &&
            cart.map((product) => (
              <div key={product.id} className="text-white font-semibold">
                <div className="p-6 bg-yellow-400 rounded-t-xl">
                  <div>
                    <img src={product.image} alt="" />
                  </div>
                </div>
                <div className="p-6 bg-purple-500">
                  نام محصول: {product.name}
                </div>
                <div className="p-6 bg-indigo-600">
                  قیمت محصول: {product.price} تومان
                </div>
                <div className="p-6 bg-green-500">
                  وزن محصول: {product.weight} گرم
                </div>
                <div className="p-6 bg-pink-600">
                  اسباب محصول: {product.eqs}
                </div>
                <div className="p-6 bg-black rounded-b-xl">
                  تعداد محصول: {product.qty} عدد
                </div>
                <div className="text-center">
                  <button
                    onClick={() => handleRemoveFromCart(product.id)}
                    className="bg-red-600 my-10 p-3 rounded-xl text-white font-bold"
                  >
                    حذف محصول
                  </button>
                </div>
              </div>
            ))}
          <div className="p-6 bg-slate-600 text-white rounded-xl">
            قیمت کل:{" "}
            {cart.reduce((total, product) => {
              return total + product.price * product.qty;
            }, 0)}{" "}
            تومان
          </div>
          <div className="text-center">
            <button
              onClick={() => handleClearCart()}
              className="bg-black font-bold text-white p-3 rounded-xl cursor-pointer my-2"
            >
              حذف سبد خرید
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default ShoppingCart;
