const Home = () => {
  return (
    <div>
      <h2 className="text-center text-indigo-600 text-2xl mt-12 font-bold">
        پروژه ی سبد خرید
      </h2>
    </div>
  );
};
export default Home;
