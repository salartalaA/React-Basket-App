import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getProducts } from "../redux/products/action";
import { Link } from "react-router-dom";

const Products = () => {
  const { products } = useSelector((state) => state.product);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getProducts());
  }, [dispatch]);
  return (
    <div className="container">
      <div className="mt-10">
        <h2 className="text-center my-10 text-blue-700 font-bold text-2xl">لیست محصولات:</h2>
        <div className="flex justify-between">
          {products &&
            products.map((product) => (
              <div key={product.id}>
                <Link to={`/products/${product.id}`} className="min-w-72">
                  <div className="bg-yellow-300 rounded-t-xl">
                    <img
                      src={product.image}
                      className="w-72 rounded-t-xl"
                      alt=""
                    />
                  </div>
                  <div className="bg-red-700 text-white h-auto mb-10 p-4 rounded-b-xl">
                    <div>
                      <span className="font-bold">{product.price} تومان</span>
                    </div>
                    <div>
                      <span className="font-light">{product.name}</span>
                    </div>
                  </div>
                </Link>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};
export default Products;
