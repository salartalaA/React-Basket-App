import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getProducts } from "../redux/products/action";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faArrowsLeftRight,
  faCartShopping,
  faHeart,
  faStar,
} from "@fortawesome/free-solid-svg-icons";

const Products = () => {
  const { products } = useSelector((state) => state.product);

  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getProducts());
  }, [dispatch]);
  return (
    <div className="container">
      <div className="md:flex mx-10 mt-4">
        <div className="sm:w-96">
          <div className="border-2 border-slate-200 h-auto w-full mt-10 rounded-xl text-xs p-3 font-semibold">
            <div>دسته های محصولات</div>
            <hr className="my-4" />
            <div className="leading-9">
              <div> آسیاب قهوه</div>
              <div> اسپرسوسازها </div>
              <div> تجهیزات بار سرد</div>
              <div> تجهیزات جانبی</div>
              <div> تجهیزات دمی و نسل سوم</div>
              <div> دان قهوه و پودر قهوه </div>
              <div> فرنج پرس ها</div>
              <div> فروش ویژه </div>
              <div> لوازم یدکی </div>
              <div>ماگ و فنجان </div>
              <div>محصولات فوری و پوری </div>
              <div>موکاپات ها</div>
            </div>
          </div>
          <div className="border-2 border-slate-200 h-auto w-full my-10 rounded-xl text-xs p-3 font-semibold">
            <div> برندها </div>
            <hr className="my-4" />
            <div className="grid grid-cols-2 mt-12 mx-4 text-center gap-3">
              <div className="max-w-28 border-2 border-slate-200 p-2 rounded-xl">
                <div>
                  <img
                    src="https://28coffee.ir/wp-content/uploads/2024/04/smeg.jpg"
                    alt=""
                  />
                </div>
                اسمگ
              </div>
              <div className="max-w-24 border-2 border-slate-200 p-2 rounded-xl">
                <div>
                  <img
                    src="https://28coffee.ir/wp-content/uploads/2024/04/barni.jpg"
                    alt=""
                  />
                </div>
                بارنی
              </div>
              <div className="max-w-24 border-2 border-slate-200 p-2 rounded-xl">
                <div>
                  <img
                    src="https://28coffee.ir/wp-content/uploads/2024/04/breville.jpg"
                    alt=""
                  />
                </div>
                برویل
              </div>
              <div className="max-w-24 border-2 border-slate-200 p-2 rounded-xl">
                <div>
                  <img
                    src="https://28coffee.ir/wp-content/uploads/2024/04/geepas.jpg"
                    alt=""
                  />
                </div>
                جی پاس
              </div>
              <div className="max-w-24 border-2 border-slate-200 p-2 rounded-xl">
                <div>
                  <img
                    src="https://28coffee.ir/wp-content/uploads/2024/04/gemilai.jpg"
                    alt=""
                  />
                </div>
                جیمیلای
              </div>
              <div className="max-w-24 border-2 border-slate-200 p-2 rounded-xl">
                <div>
                  <img
                    src="data:image/jpeg;base64,/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQABAAQAAABGAAD/4QMraHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjMtYzAxMSA2Ni4xNDU2NjEsIDIwMTIvMDIvMDYtMTQ6NTY6MjcgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCBDUzYgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjNBQTA0NEVBMDJEODExRUY5MThCRjhFQUQzODJDMzgxIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjNBQTA0NEVCMDJEODExRUY5MThCRjhFQUQzODJDMzgxIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6M0FBMDQ0RTgwMkQ4MTFFRjkxOEJGOEVBRDM4MkMzODEiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6M0FBMDQ0RTkwMkQ4MTFFRjkxOEJGOEVBRDM4MkMzODEiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7/7gAOQWRvYmUAZMAAAAAB/9sAhAAEAwMDAwMEAwMEBgQDBAYHBQQEBQcIBgYHBgYICggJCQkJCAoKDAwMDAwKDAwNDQwMEREREREUFBQUFBQUFBQUAQQFBQgHCA8KCg8UDg4OFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCABQAIcDAREAAhEBAxEB/8QAowABAAICAwEAAAAAAAAAAAAAAAYIBQcBAgMEAQEAAwEBAAAAAAAAAAAAAAAAAwQFAgEQAAEDAwICBwQIBAUFAAAAAAIBAwQABQYRByESMRMU1FWVCEFRIhhhcZEykhVWGYFCcglSYoIzFiNDJCYXEQACAQIDBQYFBAEFAAAAAAAAAQIRA1GhBCEx0RIUQWGRIhMVcYGxMiPwwWIF4fFScoIz/9oADAMBAAIRAxEAPwC/1AKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgIplm5u32CkLeXZJb7TJNEVuJIfBJJovQoMCquF/pGprdmc/tTZxK5GO9kWT1G7QLxG9yTH2ENouxCv1KkRUWpuju4ZriR+vDHJnPzGbQ+My/J7v3OnR3cM1xHrwxyY+YzaHxmX5Pd+506O7hmuI9eGOTHzGbQ+My/J7v3OnR3cM1xHrwxyY+YzaHxmX5Pd+506O7hmuI9eGOTHzGbQ+My/J7v3OnR3cM1xHrwxyY+YzaHxmX5Pd+506O7hmuI9eGOTHzGbQ+My/J7v3OnR3cM1xHrwxyY+YzaHxmX5Pd+506O7hmuI9eGOTHzGbQ+My/J7v3OnR3cM1xHrwxyZx8x2zQaLIyI4rftel265RWk+tx6MAp/FadHdwzXEevDEn2PZRjeWQUueL3eHebcq6dpgPtyW0X3KTZEiL9C1WnCUHSSoSqSe4y1cHQoBQGm8nyy/57e7xieGXf8A4zheNKTWcZ6Kgjrb7YdY5At5O6ti62C6yJBaozroic/RdhbUEpSVW/tj+7/ZdpBKXNVJ0S3srRevVRtPtZNkW7ZPCo94miapLzK8uGr811PvOK84hyn0JePM44H0JpWtHQ3bqrclTuX6oU5aiMHSKqYb9wTc9V0THce+hOWZ3ipPabeLyOOsngdv3AN0/wBN2D8E3vFPabeLy4HnWywQX+4DuknFcbx9E/pm94p7TbxeXAdbLBHCf3At0V6Mcx9fqGZ3intNvF5cB1ssDn9wDdP9N2D8E3vFPabeLy4DrZYIfuAbp/puwfgm94p7TbxeXAdbLBD9wDdP9N2D8E3vFPabeLy4DrZYIfuAbp/puwfgm94p7TbxeXAdbLBD9wDdP9N2D8E3vFPabeLy4DrZYI4T+4HuiXBMcx9V+gZneKe028XlwPesngdw/uA7m8ydoxiwOMf9wESYCqPtTVXyRPsWvPabeLPFrZYE5263X2g3rvzLUKM7tHvO/wALXfbQbYsTXulGnNBBqShL0sSmtSTgBa1Wvae7Zjt/JDB/rZ8ie3dhcezyyLJ7d51eblcrhgOexmYG4tiaCRI7LzJCudvcJQbuEPn49WRJyOtqqq058K9IquXdtJJTj9ryeDLkZbaPebEqsSEQ3Uyt/B9uMoyuIiFOtdukPQRVNUWUoKDCKnuVwhqexb57ijiyO5Lli2U79V14kbWbUYRsbZXzbO5xiuGUykVUdlk2Qm6rhdJdolG465r08unRW3oIq7dldfZu/XwKGpk4QUURP0KJabhuRf8AHrxaIlzjzbR2oHJjQPqycN8B0AXBJPjR5dfqSp/7Sqtpp02kOjo5NNFxbQxtzl+bZ1trKwW1C1i7VtGTKOLGMJbd4jG9ogI0KgocvL95delNKw5O5CEZ8z81cjRXLKTjTcVQwj02RshyTPoLGKW9/E8bv9xt8PI71eLhATqYx6IwDURCQ0ZH77pqnT0rpw2LuscYxfM6tLYkilCwm3sWxnredmf/AJPujtldZeD2h3D7re2La/Nh3KXd4UoriPUttvM3APgUUInQVBIT5emvI6n1bc1zOqVd1N3wDtckouipUzXrws+JYtZcMtGO41bbS/cZcyW/OgRWIjihDaBtGl6oBUhJX+biv8qVx/VylKUm23Q91iikkkV02d2GzneyXNDFkjRbXbeVLhd7gZNxmzcRVFtEATMzVE10EdETpVNUrU1GrhYXm3sp2rErm4k2b+lDcjCZdg62VbbrYcinxbVFv8B5w4bEic4LTXaOYEIQIi4GKEns6dEWG1r7c096aVaEk9LKNMGS9z0FbxhKaYbudhcYcEyclJJkiDajpoKisfmVS14aDpw41D7rapuZ30U+4h2Jek/dLLc0yfCGyt1vn4kTAXaZKfMo3PMbV1hGlabMz5wTn+6midOi8Knua+3CClt8xHHSylJrAzOQ+jHdLE8SvOZ3i5WMYNijSZ8iO3JfcccZhiRryL1CDqaD8KESe5dKjh/ZW5yUUntO3pJJVZZ/ezYo94NtMTi4BaLJYLvKkw7nPlk0EQG4xwnVIOdhlTP43B+HTj0+ysjTar0bkudtrdmXbtn1IrlSRoLZ/YTKcC9Qo4dlFnsGSyYdmdvDce4POFAeiuOjHF5pVjuqjoHqiC6zppqv+Fa0tRq43LHNFuO2hVtWXG5RpPYah9Qltcx/enKILVsgY+7GkR3W4FjM+yMEcdp0SaIgaVCXm5y5QFEPXlTSr2kfNZW1v4le/wCW4+wuJj+fSsw2g2032lHrlmHXaPaMilImhSIE2UFqnCenSjguMyvoMU0rCnaULs7XZJVX1XA0VOsIz7UWwrHLxrX1A26Vc9l80YhArslm2uTAaRNVPsJDKUUT3qjSpVrSNK7GuJDfVYMqN68IJXebt/uLb16/H7xajisSQ4hzKSS2uP8AnbeVR9/KtbX9U6c0HvTKGsVaSMX6BbVNk7rXy7tAiwYFkcZkmpIio5LkNK0iJ0rqjR/VpUn9rJK2l3nGiT5m+4uliWDXew7qbi5zOdjraMqCzBbm2yJXg/K4psuq6iigjqRfDoS8OnSsG5dUrcIrfGuZpRg1OUsaEE2svdqyvbndgsfixssV3IspVuxK6AtzhkmZMsGq8BCQK6IS8FRasX4uNyFfLsjtw/0I7brGVNu1mG3RhZY9B2bxqbb7Paf/AGywvQrBAfcWRHZtzLjrrYoaCBNx2xUSUf8ALp0pXdhxrclVvyy2/E4uKVIrZvRs3PdrI2e7hYZf73CgXPFseiXdufbri0MhHZE8YwsKLRgQLy9WZKSrw4adNVbV924SSqm6E07fNJN7lUie29ostpzHfDD8Zhxbejcm3nEs0MG44AEqyMIhC0KCIobnNx0011qa9JuFuUtu/b/2OLaSlJL9bCDZXYbrifpW29wa+sJAykrljdv/ACtxxtXSlJdGXSbHlJRJURFVeVamtyUtRKS3Ul9BPZBJm083jXAd/tqZ4ISWtYeRxHSQ9AV84zLoCo68fhbJUXT2VVtNejNdvlO5/wDpH5mP20NuJv8Ab1W+S623Omrjs+LGUx6xyKNvJlXBHXXlQ05V9y6e9K6vbbFt/wDL6nNvZcl8iEZbh9/wX0V5HimTAAXyHAndoBp3rw/8i5m83oft1Bwanhcjc1alHd/g5UXC1R/raS/ca13Ri27GpyE2lryayt3FBNE5OaC8xoui/EnOqDw1qGzJVud8X9TqadI/FHxXK1zy9ZlluQsqUJMHkKTqKmgoE4gXVNdU+JwE/jXSkuka/l+x41+b5FLvV7EkRfUJlpSG1AZKQX2FXT4mihMghJp9Ikn8K3v69p2I/P6mZql+Rm/NtrBMtPpBs9ikgoXPPsjgN2lguBKk27R+QtPd1Ec3v6eNZt6aeqb7Ip/QuQjSyliy7FYJonVxtt1s2nRQ2jRRMCTUSEk0VFRelFoCst/w7HLdZZXp53SIo+391eU9sstJUQIrikRtW5x0+DcmMRKMfnXleZ+DpRRXVhck360PuX3L9/g+3BlSUVTklu7CqOY+nr1AbN3OWuPsXSbaHfhG+Ys5I0eZFVUeuajF1oKmv3TFRRegl6a2bersXl5qVwZnysXLe4g8pzfeYw7DmlmMiK8Kg8w9+am2YrwUSEtUVF9y1YXoLdy5Ef5e8+KwWvd7FJRTsXt+S2WYY8jj9ujz4pkKdCErQDqn0LXU5WpqknF+BzGNyO6p3nwd5Lrdm79c4mUTL4z/ALNzfZuLkpv2fA6QqQ9P8q0TspUXLT5HrVxuu0+nrN9v8WY/bda5/B/HI9/L3nhBi7z2u9Fkdui5TFyEh5DurTNxGWQ6InKTqDzkmiImirpwr1uy1R8tPkeJXE67Tve2t68luEa7ZDHym6XSESHCmTGbg86wQqhIrRGKqCoqIuo6caRdmKouVL5CSuPfU93ZO/ciRHlvuZi7LiKZRHz/ADUnGVcHkNWyXiPMK8q6dKcK8/B/HIUu95sjZDJpuJZfcsh3ewHJcycnsMsRbq5ClS58MmVLVRKQgkokJIK6OJpp7aqaqCnFK3KMSxZbTrJNm0NzN5rVL2eue022u32YFHuqPB2y9QZCJHCTKWW5oWrzjioRKIIWmiaceGi1LOnauq5OUdmBPcueTlimVikpvlMBpuYmXyG2DF5gHUujiNut/cMELXlIfYqcUrXXor/bkUKXO86tQN75FwCWzFy126q2sduQLd0KR1REhK2h6c3KpIi8uumtK2aU8tPkKXK12m6NtfSxm2VTv+d79S3scwm3iki5u3uUqXGSwzx6sydNVYa04EbhISJwEfalC9roQXJa2yeG4s29PJvmnuLa4RELc3K7VngQCtm1+IsnF27tzrSsFNfdb6g7orJIigyLOrMMSTVRInOGo1i3H6cXGtZS+7hxL8VzOvYtxuqqJYFAY++WKzZLapVjyCAxc7PNBW5UKW2LrLgr7FEkVOHSi+xeKV1GTi6p0Z40nvNatbT5jiaI1thn8y12gP8AZx7IY6ZBb2hToBlxxxqU2CJ0D2gkT2JVr14T++NXitn+CH02vtf7nqkP1Ij8P5vhTmn86266Cq/SqJMXT7aV0+EvFcBS7isx2X1I+K4T5fde+Urp8JeK4Cl3uzHZfUj4rhPl9175Sunwl4rgKXe7Mdl9SPiuE+X3XvlK6fCXiuApd7sx2X1I+K4T5fde+Urp8JeK4Cl3uzHZfUj4rhPl9175Sunwl4rgKXe7Mdl9SPiuE+X3XvlK6fCXiuApd7sx2X1I+K4T5fde+Urp8JeK4Cl3uzHZfUj4rhPl9175Sunwl4rgKXe7Mdl9SPiuE+X3XvlK6fCXiuApd7swtt9R0n/pO5Dh8AC6ZEe03GQ6P9IOzhH7ac1hdkvFcBS5ijmHspHus6Pd90chnZ9PiOI9EgzwaiWRh0F1E27bHRGiJPYT6uqlePU0VIJR+vieq32ydTaaIgogimiJwRE6ESqhMc0AoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAf/2Q=="
                    alt=""
                  />
                </div>
                داونگی
              </div>
              <div className="max-w-24 border-2 border-slate-200 p-2 rounded-xl">
                <div>
                  <img
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIcAAABQCAIAAAC8vvHKAAAHP0lEQVR42u2YCWxURRiAZz1BBRPvoFFiTKuJRzQaEzUxxiiUHrvd7tFuW9QqUEoRKlA8MBKxLNSiEgwB5KY1ooabKIqUK4iSIqLcFCiEBeQoFPbN/caZ7du+NqRiSGhmyXz5swnDzJt//q87M2+BMOgHEAb9MFZ0xFjREWNFR4wVHTFWdMRY0RFjRUeMFR0xVnTEWNERY0VHjBUdMVZ0xFjREWNFR4wVHTFWdMRY0RFjRUeMFR0xVnTEWNERY0VHjBUdMVZ0xFjREWNFR4wVHTFWdMRY0ZEraIUwHkfsPGTnLHbmAjt1njXHGeVMCFu0w7ZtTJkMRBhlXCThto1UO1ft3G0nlMt2GYS6jZTJbs5DuN3Z850hbnpYpXfWTU+OZaITGGd7Y7jhIN5+mOw/Tpov0JS0El0S7z0QP1CO7y0jdw8idw7A95Tix0bhkqnw171YJGk6SZ4YjdLfoWnlpHQmbHP22z6S/jZ8eARJKyMTl8VFAkRp32g8bRiRkTHBItQp4vglMG0ITn+HpA9Hv+/Hoh2y3M+OsdIrSNrbpGCKlXy+PbI23nsQeWAo7lVG7hpE7hiAew3GT1SiwTPgtkNYdIDPW289VQm7FVNPhF1XxLpH6IsfW5zT1LMybB4EmQKEkhFOfAYE8Irrw+TLVU6B9h2j10Q4yBMgW7waxW1WftlBgJep/pli+DzkWCGs91AEfELGg8MITlopn4NlN9U5l6/dSUQ7TrSwm1/HwC9AjnjmA9JmJX8KAlkXp6e63VKE6zZawsGuWhwHPqoyzE+GX6SPpJSx1LMyohbK2nkiKkDQBnkc5KoleQrV+j1BUr9D1Xr/cXrTa6x1qZk1rpX6nQQEGChQAkbWulbSKxAIChmPjHCtDJ+PZTfVOcTW76KiHf+0sNsGYFX0PPH8R66V4qkI5CbTC/AO6QVFt0K87ZCadFsTvq5ADlftSow/sZAs+75yjGnKWklUio9fClduxe9/Y/V4naiVR1St+01U+1Xjf1gJXmkraognwif/CJc34Ir5sFsRddLzitemqvTGfg+B11YtIbtvFM1bj5Y3oFlrUM3yOCIpbSXINu8nQmHPXQc9Ae5R5RN3DcQXEGs66VrxTUJtVhoOUhDqCivXRNjumJPepBUWyOPKQVA8NBzbNn1jGna6hVnDQSgkKX0Ha2+lPrnXHz9Hbymhqkb5ont/euS0CsdKSKRVkE8W4XGLSNUi/NYMBPJlgbrCytaDTnpSz7VFKhnZ//a3CKZ0xALU+l3xhMVDw/CHC+HWA1gIflVZ+esIvj5CVWNY9Cwhp8/Tw6ccK0pAWDqwVXht4FctXWxl7U7kad02Q+LeMsxtJg8/4KfJ41Cld22EPj8G1W2E0k1qW9m0Tx0YTSdx3ygEeYla+8WzY1Rj4wnXivwEgWSEus7KzqMqkz0x9NyHCAQSk+Y6x54QvGKBBbxUtjhJFqjkZYu8+ssOKWklUWv7hbGoTxTdPgA7SmTk8GmrYfs7mCdf9HiDPVaJH60kj48m8uLrKbCvtJWEeP7SJ/CVKtizBCslhYnn+Nh3m6Fw4As3wYzx8Kb+BPhs5z4WlNniWDNJVSsyQCDx9xVOfiGy7H4TLVXTjjfjjAmIcUo5YzyxdYS66mac56anembx4i+ti97z+d4YqV4Ke5US1UeNYj9tx6lsJU+oqnnlJ+9eSEpnWC2QCklHK9k17h1sw256eTfjLY2q9E78PytKia81eI/+ZGSt1Xbr5TbveH6w4qmWHAjUKL5ia+paCfOcGjhkNpLFnf4z2nXUKc3FVrI+RZf9vuLMlW9nVcOBM9Cb0/GgmfDEWdYc55eyYocmoyGz8eg6+SICG493SG/lHyhjHBxVh6qXoarFKPA5vLGIeQoSZ0yYbj+cmlaA2r6c01604wpZcb+XOWre3THaAvml3iJlN9JZenUbMehnA1/ycuhvHaKe/9I4SDlPMSvlcyHoI9TKM9mq7UR0wt5jFISZWnaGeLnKtbL6bwKymBreRwyd61q5rwyBbCHj/nLXyuBZWM3lbxdeaU5ZOQf5DcVE/bOfePI9ktyO7OBkBPom/PnZlgNUdELtBgwy7cQPZckIyNntRyrgnhhOvZvxnHWWN4pyJ2FftfVnU6cLiDXT4BdWzqcoezz6eFFcJJGbQ/aEuGzPqoKz6i2RgDBWOvNC9gQkY/DsOGWOla/WWDlR5P8Mt4WcN/g5jJ2hccwLp8RzqlF2FFV+7d5lv/hBpeerkaNg44lOrdTvgE+Ngr3K8K1v0p4l9M6B5Ol30dhvrZMtJCXfIhPYTlxON7tDuFyy0Y2L//ey0uNnLXb0jPwZgpw6z4TgKfyLi8FYuaowVnTEWNERY0VHjBUdMVZ0xFjREWNFR4wVHTFWdMRY0RFjRUeMFR0xVnTEWNERY0VHjBUdMVZ0xFjREWNFR4wVHTFWdMRY0RFjRUeMFR0xVnTEWNERY0VHjBUdMVZ05F8e/vHm8tS8rQAAAABJRU5ErkJggg=="
                    alt=""
                  />
                </div>
                فیلیپس
              </div>
              <div className="max-w-24 border-2 border-slate-200 p-2 rounded-xl">
                <div>
                  <img
                    src="data:image/jpeg;base64,/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQABAAQAAABGAAD/4QMraHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjMtYzAxMSA2Ni4xNDU2NjEsIDIwMTIvMDIvMDYtMTQ6NTY6MjcgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCBDUzYgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjYzRDEyQ0M2MDJEOTExRUZBNUJEQUE4OUVEMzE3NjczIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjYzRDEyQ0M3MDJEOTExRUZBNUJEQUE4OUVEMzE3NjczIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NjNEMTJDQzQwMkQ5MTFFRkE1QkRBQTg5RUQzMTc2NzMiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6NjNEMTJDQzUwMkQ5MTFFRkE1QkRBQTg5RUQzMTc2NzMiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7/7gAOQWRvYmUAZMAAAAAB/9sAhAAEAwMDAwMEAwMEBgQDBAYHBQQEBQcIBgYHBgYICggJCQkJCAoKDAwMDAwKDAwNDQwMEREREREUFBQUFBQUFBQUAQQFBQgHCA8KCg8UDg4OFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCABQAIcDAREAAhEBAxEB/8QAnAABAAIDAQEBAAAAAAAAAAAAAAYHAwUICQQBAQEBAQEBAQAAAAAAAAAAAAAAAwQCAQUQAAEDAwMBBgIFBg4DAAAAAAECAwQABQYREgchMUEiExQIYTJRcYGhI0Izs7QVN5FSYnKSwnMkRGR0NWUWdXY4EQACAgECBQIGAwEAAAAAAAAAARECAzESIUFxMgRRgWGRIkITM6HRciP/2gAMAwEAAhEDEQA/AO/qAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFARDk/PYHGuE3TLJu1x2K3sgRVHT1ExzwstDv0KuqtOoQFK7qjlyLHV2ZXFjeS0Ioz2zXD3ApC3Mxtblwwa8PuS2rhc5CY8+M5IUp1brLSgVrZWo67FBI67kHTUKj49rtcVwKZq1ThE8565ysvGeKT2bJdYb+fulMe22wONPOsuqIKnX2txKUIRqRuHiVoO/UUy5lRfE5x4nd/AkPCXKkbl/BI+UJjCFc2XVwbxCSSUNTWUpUrYVdShSVpWnXsCtCSQapS+5STvXa4LFqhwKAUAoBQCgFAKAUAoBQCgI1kua23HlpgMMP3jInk7olitqPOludQNy+oQy316uPKSn4k9KlfIq8NX6FaY3bjovUhH/RH8guTGfc2SoaGrWS9aMYS8DZrYD1Dkh10IEiQBoFLUA2D8oI00h+Lc92Tly5It+XatuPnz5srnlX3XYixKGKYpLnPQHypu85PaEtl9hkoVqmAJBSlTpVoPNV4UDUo3K00jl8yswvn/RbF4dol/L+ziGZi+Sy4r1/Va7g/bHFKecubjDy2lbiSVre2lJJPadaw1TfE2XaXA659kPJNsEO5cWzmm492Lrl2tsodFS0lCEPNr17XGwhJTp2o1/ian6fjWUQfMzptydj1tMpRt8kSE+6zGY6X3Exl4s+pbAWoNqIfk6EoB0J+z6PorM/2roaF+t9S8q0mcqK7c9W21I5GU5ZZDh48XCbkpS62PV+vcLaSjUeDaRqdden8FQeZKeHaXWKY+JZmP3ZF/sNrvrbSo6LpEjzUsLIUpsSWkuhJI6Ejdp0q1XKki1DgrK9c9W6xp5E9VZJBc49XBS+gPN/3tNyc8ttSDp4ANQo669D9PSoPMlPDtLLFMcdTa2TmCBfcuxjFItrfS5kuOM5UiWtxG2PHkBW1paRqSoFOhIOnWulllpeqk5eOE36OCw5kluFEfmO6+VHbW8vTt2tpKj9wqrJEF4f5Uhcu4zJySDb3LYiNNcgLjPOJeUVNtNO79UgdCHdOo7qniyb1JXJj2OD6+VORI3FuIvZbLgOXFhl9lhUZlaWlfjq267lAjpXuS+xSeY6bnBgtfJ0W7chX3AI9teD9gtzFylzitBQVyUNuIYCB13bXNdde414sk2dfQOkVTJyh1p1Tjba0rW0oIdSkglKikKAVp2HaoH6jVSZU7ft/wAftUNMHD8myTFoqdx9PbLo55K1qUVFa0vBwqV17d1Y7eKm5VrV6M118lpQ61fVEXvPtnwh7ddM+zW+3KM0dxeulwZQ0nvOq3m1adPoUKhbwqa3s31ZevmX0rVLoiAzM19sfFszysOxVOV3iMf9wWfURwv6Uvyi4NR3Kaa0+NZnn8fE/pW5mhYfIyr6ntRILF70sSkzEQ8lxyVZ4Czs9XHeRPQhJ6arb8tlW0fyQo/CtWPzq21UGXJ4bro5IDzjjdk42yzDvcTxYplWNTpzbk1uAQIynzuUrZt6JRJaDrbiABtUD3q0FbpVatXQhVtp1Z23HfZlMNSY6w4w8hLjSx2KQsagj6wa2mYo2+//AFli3/qsj9PKrK/2roaF+p9S9q1Gc4xzD5Pcz/a2L9YVXzrff7G6v2e51Vx5+7/FP/D2/wDVW63U7V0Md+5nLfNsdyNkXMlpij8bJI+JqZQem50SWmxp9ZRWLLrZesGzFpX4SSfgZSLzyLj1z0CxauN7ZA3DqEOGSEj7SlCq7w8bL/Jxl4Vf+i+OSpxtnHWW3FJ2ri2a4OoI7d6IzhT99asjir6GeimyKN9m6Tb7LlViVqFx37ZPUD/yMFK/6lZvF4Jo0eRqmSj3cfuYuH+thfpRXfk9hx4/eaThXLbJdbtzFzEtxarEt9opcUj8UQLTEWsnyvm6t7dB8NK5xWTdrHWSrSrUkTWdSMT5Y5PsNwV5nm2aLl2PxVnaHEQoXpZSEnv1Wwg6Dr8x7q6VovZe5y6zSr9jnu6c85pebSb1lrUbI+OL+4mBfMfS36b0EtnRYQw+j8RpSwgPsLWtYOih2oURltkdlx41ZoVFW3Dg0VVyJYF4vdYbkO4u3XFr1Ebu2OXB9W5xyE+SAh0AkJeaUlTbqe5Q7ACK+Xmw7X6rkfTw51Zej5kSVNGnbUFjKvKa6TJCtetaqUMl7ySK18mT7fx3knG0xozbJenI0y3lThBgToz6HFOtjQgh1tKm1p+pQ7DrupaKwYLKXJ6e8eeb/wBAxTz/AM9+x7f5n870rev319SuiMT1Ksv6ko92OLqWoJSMVf6kgD8/J+ms7/auhdfqfUvetRnOMcwI2e5k6gfjWIdSB/iFV8633+xur9nudU8d9eP8UP8Aw9v/AFVut1O1dDJfuZznzfAkOe5HA4I8VtvwtAmtafP6C4uuEH4aaVkyr/oviacT/wCbMns9iyDd84dkr3/shMGyxiR18pl2Urr9Wgp42rHkaIuH3CTjbuGMxfCthXB9Pqf806hjT7d+laMzijIYV9aKs9tEye3yJmtuulpXY5ci0Y88m3LdS/o3DhpYS5vSAPxQsOafk7tp7Khgf1P2LZu1e5K/dx+5e4f62F+lFU8nsOPH7zDxaqLZuZ+XcY2IFvli3XuO0EAILciPve0HYRq8lPZ3V5j4XshfjSrNJ7rrNfceVi/N+JICrzhz5j3JJSVIct8o7dHQCCWtylNLAPyvH6x55Cai65HWCyc1fM5ztdpx2/y5dxwfKLLasLvwS3kGJZJcBb5UBClbyhKnk6SEx1eONIZKnOwLTqVpVmqk9HwfIrZvmuJGuWsqxlcDFePsOuK73YsKjzI4yBxkxTNkXCUqS6UNFSiGkeFKCTqevdoTxlhwlyOsbalvmVcZavpqew73mJx9Su+ukjl2JDx3h8/kTOLHh0AK826ykNPOJGvlR0+N90/BttKl/ZVaVlwSs4R67sMtRmW47CA2wylLbTaegShA0AH1AV9QxEHzfhrjfka5s3jMbN+0bjHYTEafEmVHIYStbgTow62Dopaj1HfUr4q2ctFK5LV0JnbrfEtNviWqAgtQYLLcaK0VKWUtMoCEJ3LJUdAB1USaolBw3JAsp4K4uzO/qybILGJF2d8v1Tjb77CJHkgBHnIacSlegSBqR1A61K2GtnLRSuW1VCZYbTTTDSGWUJbZbSENtoASlKUjQAAdAAOyrEiP3fA8Uv2SWjLrrbhIyGxbha5hcdQWt2pPgQsIV1PTek6Vw6JuXqjpXaUH5ieBYng5uSsXtwgKu8gzLiQ4675j518X4q17R1PhToKVoq6C13bU+vKsUsGbWORjeTRPXWaWW1SI3mONbiy4l1HiaUhQ0UkHoa9tVWUMVs6uUfPbcGxW0ZFIyu225Ma/SobVtflIW5oqJHCA2jyyooG0ISNQnXQdteKiTkOzagy5bh+OZzZl4/lUIXC0OONvLjFxxrVbStyTuaUhXQ/GvbVVlDFbOrlGNjCMXjZLKy9i3pbyCbCTa5UsLc0choKSlBb3bOmxPi27tBprXmxTPMbnEG2uVug3i3yrTdI6JdtnMrjS4zo3NusupKFoUO8EHSumpPE4PObnj2z5LxjcJV7xyM9d8BWoutS2kl1+Cgn83JSOuiddA7ptPfoelfOyYXXTQ20y7tdSgiaidNn4BXp4bfHMVyPMbq1ZMXtki63V75I0VBWoDvUo9iUjvUogDvNepN6BtI9Dvbd7d43EFudvuQKbmZ7c2w3Icb8TMKOdFGO0r8pRI1cX36AJ6DVX0MWPbrqZL3kvyrExQCgKmznCcuvU7Mn7IhKFXi2WyJa5KprjH4saUpx5JQkEI2pO7f2q129lQvRuYLVslEm8OL3tN/hXDalyInIZNzfAWklMVy3KjNkpV8xDmnxT3V1tc+5zuUexNw3I9UXS8DFLYSI+wahwKJK9+uvUaDTSqkyrrZh+ZQrgh3akRlZrLvkgeq7bS7EdZb0A7SXFhXl/DWoKtv5LOy/gw2fBMui41GtU/a7ckWvI4TkkvJdHqbnJS5FUVK0UNUDQlPy6adlFRxHUOyn5EgwLFLzYXLbIuxPnsY7bbRK0kKeQZUJbxWQD29Fjx9p7O6uqVa19Dm9k/mT2qkxQCgHb0PZQFc5FwLw7lUpc29YfAcmOnc6/HSuG4tR71KiqaKj8TU3jq+R0rtGlje1vgWK4HWsOZUodzsuc8n+i5IUPurz8VPQ9/JYsuwYzjuKwhbsatUS0QRoSxBYbjoJHeoIA1PxNUSS0OW2za16eCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUAoBQCgFAKAUB/9k="
                    alt=""
                  />
                </div>
                لواک
              </div>
              <div className="max-w-24 border-2 border-slate-200 p-2 rounded-xl">
                <div>
                  <img
                    src="data:image/jpeg;base64,/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQABAAQAAABGAAD/4QMraHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjMtYzAxMSA2Ni4xNDU2NjEsIDIwMTIvMDIvMDYtMTQ6NTY6MjcgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCBDUzYgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkExOTVCQzUwMDJEOTExRUZBNDgwREJDRUQ5MUY1NjI2IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkExOTVCQzUxMDJEOTExRUZBNDgwREJDRUQ5MUY1NjI2Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6QTE5NUJDNEUwMkQ5MTFFRkE0ODBEQkNFRDkxRjU2MjYiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6QTE5NUJDNEYwMkQ5MTFFRkE0ODBEQkNFRDkxRjU2MjYiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7/7gAOQWRvYmUAZMAAAAAB/9sAhAAEAwMDAwMEAwMEBgQDBAYHBQQEBQcIBgYHBgYICggJCQkJCAoKDAwMDAwKDAwNDQwMEREREREUFBQUFBQUFBQUAQQFBQgHCA8KCg8UDg4OFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCABQAIcDAREAAhEBAxEB/8QAnwABAAICAwEAAAAAAAAAAAAAAAYHBQgCAwQBAQEAAgIDAQAAAAAAAAAAAAAAAwUCBAYHCAEQAAEDAwMDAgQDBgcBAAAAAAIBAwQABQYREgchEwgxQSIjFBVhcTJRgUJSYhaRcnO0NRc3GBEBAAECAwYEBAILAQAAAAAAAAECAxEEBSExQXESBlFhgULwIjIUkTPBUoKywhMjcyQ0NRb/2gAMAwEAAhEDEQA/AN/qBQKBQKBQKBQKBQKBQKBQKBQKBQKBQKBQKBQKBQKBQKBQKBQKBQKBQKCOys9wyFfmsXl3yGzfnk1CEbooevsJL+kSX2AlQl9kqOblMThjtW1vSM5csTmKbVU2492HxjHnGyEiqRUlAoFAoFAoFAoFAoFAoI7a80s1zyi+YeDqNXyxmx3YzhIhPMyY7cgXW09xTeoFp6KnX9SVHFyJqmnjC2v6XetZa1mZjG3d6tvhNNU04T+GMePpLrzDkHEcDjDIye5NwycAjjx9FN97Zoio22KKq9VRP2J718ru00b5Zabo2b1CrpsUTVhvnhHOWq3I/kxk2To9bMSE7BZD1EpAkn3B0V/a4PRr8m11/qqsu5uqrZTsh3XonYuWymFzM4Xrnh7I9Pd67PJUmOYvkua3VLbj8F65XF1dzigmqDuXqbrhaCCa/wARqlalNFVc4Q51nc/lsja671UUUx8YRG+eUN2OJsJ5Jw6ExEynKGbpbUb0+1Eyb7kclTojcsjElQfTaoKP8ulXNm3XTG2cXnbuLVdOztc1ZexNurH68YiKudGGHrjE+K0q2nCygUCgUCgUCgUCgUCg0U8gZE6282X2dDddiSgWC7GktETTiKkFgdwGOipoqKmqLVHmZmLs/HB6V7Ooou6LaoqiKo+eJidsfmVb4SLF/IONd7eOLcw2lvIrGegfcUbFZTfoiEYJtQlT+cFE/wDMtSUZnGMK4xhU5/s2qzc+40y5Nm5+rj8s8p4cpxp5JB/0PxK+P9/MZeo8ZCPccb1TuC5vQe13iTciKq7dit9z29etSfb2/qx+VV/+u1Wmfs5y/wDl7vLDx6d3r1dPHcy+F8v49JzawcccV2Zqz4s9IL6y4PN/PkAy0bpIIKqkm7Zp3HCI/wAErO3fjqiiiMIaGqdt5ijJXc7qFybl6KdlMTspxmI3+WP00xEc2yVWLqNrp5cc6Ztwbj+M3LB4cCbPvVwcgvNXFl6Qm0Wt4o2LLrK7lL8VoMRbvKmXI8VJ3NcmLDDOLeTloftIi4kVL39QLDQdsnO5tVtxuQQb9duqa+9BFOKfKzlDM+IOW85yC22iLkOBx2XLZGZjSWmVdMHlMZDbkgyXRW06CQ+9BjMM558vs8sFtyOwW7j9YV2FVhsyZasSlVHCb0Jk7ghoSkPRFTWgl/NXPXN+B5jxtx9jsLG28qy20NP3j7t3/omLr1F4G3xkNILKEJIKluVaDjx95FcyMc2WThzlKy47Pdv8ZyWxc8RfdfSIAg6SE+hOvJt1ZVCRdiohIWqp0UOXkr5M8i8eZsuEcRWWDfZ1jsjuSZk7NadkpDhIYoK6NPsbNgKjjmu7o4GnvQT7MfI63Y946ReeLRbfuiXCHDci24TVG25swxYNt5wUXQWHd4Hp6qO1NNdaCncV508s8igQcsx624JmdrnNtyTxqx3AUujTTyIStkhS1VtxtF0cEt6iqLqnSgsvkPnrKcK8huPeLn27TCxTJrYk6+S5in3mHtZaELUgnWm0FFYBE3N6lr+KUHDkLyFu1j534143w+RZrrjGWrsvEoCWVJaLukOjZsvoAfCiL8YFQe3inm3Ls3585N4wu8aA3j2Hf8W9GadCWfzhb+cZukJdF/hAaC3MwwPFc7gfb8mtzcsRRexIT4JDKr7tuj8Q/l6L7otR126a4wmFvpur5rT7nXYrmnxj2zzjd+nwapcj+NGUYsj1zxQjyCyBqRMgKfXsin8zY9HE/Fvr/SlVV3KVU7adsO7tE75yubwt5j+jc8fZPr7f2vxe+ICh4o3MSHaaXYUJFTRUVJTKdayj/Xnm1bk491Uf2/4KkH4A/wDX8Z/1ZH+0eqDLfmQ5J3h/yb/Kn9+lv1V88wNWPNfBs5za18f/ANjWOXe5dpvv10sYQIastgA6EWqpoiqlBV1y4E5RLyCfwKLZXD4CuOaxs/lTyZH6LuNxyfdj7hL4QVTOLs29VQF9ESg9uEcWcmReOvJmBcMUnRbll8t5/HYhNiKzUddll8hELqiIY/4ppQVtx7x/kGF2uyLdvFW5ZBl9ncGQWRneZ0RXpLTyutOLGADbHZ8KbeqLt6+tBYvkbiHIfJOb8U59cOKLjkFrj2YXspxNh0k7T7rpmcM5AIJIQ6ou7YlB5eNeP+SoXNuP5fxxxTceIMHt7BJmMeROOcNzitETpNIy6qEZmmjbYAK6HoaqmnQOzAOEvJHOMg5H5NnSYGEXHO35Vqn2jI7f9fKOzOgOjIaoWxjtkDHrqXa6+iUGU4bxjnrj7hzkXh+Xx+xk821T1cxdi+gJWO5wXn0CY2HdNoTD5avtARipK6q/w6UFP5dw7kOZMx4OBeON7wLP1kMr97au8j7U0oGikYpKEWx19lF0dnrqtBcHJHAGY5zzVw1b+QLNLy7FbXi8O15xkDRuBGcnMpLVxTfA23dVcUDUuiluT3VaDtyLxkg8feSHFV54jwyZHwyG8MnI7g08/LYZdR0xQnDkuuEOgaKunT99BNuEMCzSweUHMeW3qxS4OM33X7RdHgQWJOkgCTtkirrqia0G01AoKb8ibdBt/EV/WDGbjfVTIsqT2hQEcfcktIbhaaakWibl96081ERbnBz/ALLvV3NWtddU1dNNVMY8IimrCOUKA8c8VyG48i2fIolvdOx2w3im3BU2sBvjuNoKEWiEW4k+EdV/dWhlaJmuJw2O0e9dQy9rT7lmquP5lcR008fqid3CPOW8dXbzeUCgUCgjC8g4kMvLITk/tvYO01IyZTbcEIrT8X60C3KOhp2fjXZrp6etBiZvMmAQ8MsOejPemY7kzrMaxOQYkmXIkyJIOOA0LDLZOoaI05uFRRRUVRdFoPSfLPHjY4cZX1nt58fbxM9rm2aSto6mmo/B0IR+Zt+IhH9S6UHVceX+P7VkN2xWfdkav9kK1hcIStOqY/fZDUWGQaD8wSdebAyDVG9yb9utBOaBQKBQKBQR3LcKsmbsQoWQi7ItkOQktYAn22H3AFRBHtqbiEdyqgoSIq+utR124r3rXTtUv5CqquzhFdVPT1YYzTHHp4RM+OHLBm4cOJb4zUKBHbiw2BQGY7AC22Ap7CIoiIn5VnEYbldcu13Kpqrmaqp3zO2Z9XfX1GUCgUCgqWR4/YxPs+XWi8X2+3Is4kwJGSXB+VHblvs2tGxZioceM0IMqDaNnsBHCFV+PVdaD5/864E5jELDJsi53DF4GRFlce2zZISG/qTRxTjGptKRxicdcdIDJTUyVd+nSg55v494PnV0i3edLulqkWyBGtliZs0oYEa2hClJMbcjMg2oI53QaX5gmPyg0FNtB8yXx5wPKsvczi5vTxyA7tar4L7LrIbHbKyDLbAqrKl9O8jYE+0pLuIUIVFUoLZoFAoFAoFAoFAoFAoFAoFAoFAoFAoFAoFAoFAoFAoFAoFAoFAoFAoFAoFB/9k="
                    alt=""
                  />
                </div>
                مباشی
              </div>
              <div className="max-w-24 border-2 border-slate-200 p-2 rounded-xl">
                <div>
                  <img
                    src="data:image/jpeg;base64,/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQABAAQAAABGAAD/4QMraHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjMtYzAxMSA2Ni4xNDU2NjEsIDIwMTIvMDIvMDYtMTQ6NTY6MjcgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCBDUzYgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkQ4RDMxMTVFMDJEOTExRUY5NjQzOEVGRDMzNzAwMUM1IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkQ4RDMxMTVGMDJEOTExRUY5NjQzOEVGRDMzNzAwMUM1Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RDhEMzExNUMwMkQ5MTFFRjk2NDM4RUZEMzM3MDAxQzUiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6RDhEMzExNUQwMkQ5MTFFRjk2NDM4RUZEMzM3MDAxQzUiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7/7gAOQWRvYmUAZMAAAAAB/9sAhAAEAwMDAwMEAwMEBgQDBAYHBQQEBQcIBgYHBgYICggJCQkJCAoKDAwMDAwKDAwNDQwMEREREREUFBQUFBQUFBQUAQQFBQgHCA8KCg8UDg4OFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCABQAIcDAREAAhEBAxEB/8QAfgABAAIDAQEBAAAAAAAAAAAAAAYIAwQHAgUBAQEBAQAAAAAAAAAAAAAAAAAAAQIQAAECBQMDAgQCBwkAAAAAAAECAwARBAUGIRIHMRMIQSJRMkIU0hhhoiMzFVWVcbHBs9OUdRY4EQEAAwEBAAAAAAAAAAAAAAAAARFBMRL/2gAMAwEAAhEDEQA/AL/QCAQCAQCAQCAQCAQCAQCAQCAQCAQCAQCAQCAQCAQCAQCAQCAQCAQCAQCAQCAQCAQCAQCAQCAQCAQCAwmspBVChNQ2K1SO6mmK090tgy3BE5yn6ygM0AgPHda7na3p7sp7JjdL+zrAfrjjbKFOOrS22kTUtRCUgfpJgND+P2L+aUn+4a/FABf7ETIXOkJPQd9v8UBvoWhaQtCgpChNKkmYI+IIgMdPV0lWFKpH230pMlFpaVgH4HaTAZoBAYPvaM1P2X3DX3gEzT7092Upz2zn0gMjrrTDanXlpbaQJqWshKQP0k6QHsEETGoPQwCAQCAoNfONrry35ZcmUVpyGpx3LMfoaa443eWFK/YVFMiibQ2vbJQaIdVPYdDrJWoJrHX+PfI2/YtkLPFfkhQpxrMtEW3J5BFouiJ7Ur7gAQgqP1j2T0IbV7YJSzKVBQCkkFJEwRqCDBFTApX5/VJ3Hb/1b5ZmX7kenSC4j12xio8lvJnNMKzG9V9Nx/gTLSKayULxZS66oNpKj1SCtalqWvaVyCUggQXHR/yN+Pv8quP9TqvxQPR+Rvx+9LXcQfQi51Mx+tA9IHx1ZLjwD5SUHENhvdbcOPcttT1wYtte6XvtnUNvuJUOiQpKqZSdyUjclfumUzgjZ5DtVf4scso5ixanWviPMahNLnNmp0zRR1TqiRUNoGgmoqcRL6itvTuJkXq29sudvvNupLvaqlFZbK5lFTR1TJ3NusupCkLSR1BBnBlAeb+XrNwxgtXlNw21F0cnS2K1kyXV1ywShEhrsTLe4odEj4kAlQPxn4gu+N09x5Y5I3VfLOak1Ve6+P2lDRukLRTJGuxRkkuJHyyS30RqJQDOq25eWPKbnFuM1r1Lw1hjndy690itK6vG5KGWlapUEqBS3OY0W5rJEF4+5495vkHGeZVvjNyhUFdxt25/Bb06Tsr7aqakspUqcyEgqbE9JLb+gTJK08EIBAVM4o/9s8t/8O3/AH26DWLD8hcbYbylj7uNZrbG7hb1zUy4fbUU7pEg6w6Pc2sfEdehmNIMq1M3XlrxEqG6LIPuc/4B3hFPdGxuulmbUZBLgJlsE/lJ7Z+lTZ9hL1o4hl2O515u0mU4pXt3Kx1+KFVPVNT6paAUhaTJSFpOikKAIPWBjZ41yCyYD5hcs2/MK5mzuZG2w7aHqxaWGXphp5KQ4shO5SVHbrrtUOukFxbIZJjpAIu9EQehFS1+KDIrJccQkqVeKJKRqSaloAfrQFUqjILNn3nLi1XiFY3dqDG7FUs3WtpFB6nQ4lmsCgHEEpO1VS0gkH5jLqDBcWtyTHbNl1huOM5DSorbLdGF0tbTODRTaxLQ+hB1SoagyI1giqnE+aVfjRm1z4I5RuJRgxQ/dcDyarO1n7QbnV061dB0V7R8rswNHEQV74us9z8m+VF855hSuNcZ4u8uk4+sdQJJfeZXM1TiOh2qSFr+Lm1HRrUcSTyq5fvtqpWuG+MGai5cmZQws1DNuSp2qo7aUqK1JCNQ66lKgk/SgKXp7YEIJxNyByTw/hVDhuO+PWQuNsfta+vW8UO1lYsDuPLApjKcgEpn7UgJ9IK+Bzff+V+Y6C1Ps8G5JjuZY/Uoq7FktM4XH6cpUFKQQGEFSSUpUPd7VpB+IIhZHx45nRy5iK0XdAos/wAeX/D8qtak9pxFS2SjvBsyKUOFKtPpWFI+mCTDsMEICIWjjHCrFnN45HtltLOY35kU10uHeeX3Wk9uSe2pZbT+6R8qR0gJfAY32GKphymqmkPUzyVNvMuJC0LQsSUlSTMEEGRBgOcYNwFxXxvlVxzHDrEm3Xq4tqYUQ664ww04oLcRTtLUUtBZSJhA9JCQ0gtt3kXhTjDlbsuZ1jzFyrKZBap64Kcp6pDZM9neZUhRTMz2qJTP0gjmv5IvHj0sFV/Uav8A1ILZ+SLx39cfqiPgbjVy/wAyBbqXHvEXHPFdO/T4JYKe0qqgkVdSkreqXgj5Qt55S1lI9E7to+EETaAhfI/E+Bcs26lted2lNyYoXS/ROJccp32VqAC9jrKkLAWBJSZyOnqBASWyWW043aKKw2KjboLPbmUU1FRsJ2ttNNiSUgf4nU+sBFMZ4gwXE8yvfINsonXMwyCYuN1rKh6qdKFKCihvuqUG0+1I2oAG1KR0AgJ1AICC0XEGC2zkWr5TtdE7Q5hcWixcX6aodap6pCkhJ71OlXaUTtSqZTPcArrBbTqCEAgEAgEAgEAgEAgEAgEAgEAgEAgEAgEAgEAgEAgEAgEAgEAgEAgEAgEAgEAgEAgEAgEAgEAgEAgEB//Z"
                    alt=""
                  />
                </div>
                نوا
              </div>
            </div>
            <div className="border-2 border-slate-200 p-2 max-w-full rounded-xl mt-3 text-center">
              <div className="w-24 mx-auto">
                <img
                  src="data:image/jpeg;base64,/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQABAAQAAABGAAD/4QMraHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjMtYzAxMSA2Ni4xNDU2NjEsIDIwMTIvMDIvMDYtMTQ6NTY6MjcgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCBDUzYgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkYwNjM3MTAxMDJEODExRUZCODlDQTkxMTExMEZGMEYxIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkYwNjM3MTAyMDJEODExRUZCODlDQTkxMTExMEZGMEYxIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RjA2MzcwRkYwMkQ4MTFFRkI4OUNBOTExMTEwRkYwRjEiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6RjA2MzcxMDAwMkQ4MTFFRkI4OUNBOTExMTEwRkYwRjEiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7/7gAOQWRvYmUAZMAAAAAB/9sAhAAEAwMDAwMEAwMEBgQDBAYHBQQEBQcIBgYHBgYICggJCQkJCAoKDAwMDAwKDAwNDQwMEREREREUFBQUFBQUFBQUAQQFBQgHCA8KCg8UDg4OFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCABQAIcDAREAAhEBAxEB/8QAiAABAAEEAwEAAAAAAAAAAAAAAAcEBQYIAQIDCQEBAAIDAQAAAAAAAAAAAAAAAAMEAgUGARAAAQMDAwMDAwIFBQAAAAAAAgEDBAAFBhESByETCDEiFEFRMiMVYXFCYhaRoUMkFxEBAAEDAwQBBQAAAAAAAAAAAAERAgMhMQRhEgUG8EFRgZET/9oADAMBAAIRAxEAPwDf6gUCgUCgUCgUCgUCgUCgUCgUCgUCg4RUJNRXVPulA3DtU9ybU11LXp09aAqoioiroq+ifeg5oFBZbPl2L5BPuNrsd3iXC42hzs3KNGeBxxg9VTQ0FenVFH+aKnqi1FZlsvmYtmJmN17kcDkceyy/LZdZbkitszFImOnzqvVSqJQKBQKBQKBQKBQKD5zeUXGWDN+W3Gdji2ZiHZ8yetBZJBiosdmWUi6nHfNRaUdpOtogmQbVVfd+Sqqh9Bo2O4/DsaYzEtMOPjaMlESztR2gg/HcRUJrsCKN7CRVRR26LrQQZ488T8d4lmfK95sNkgt3WHl0i32+a20KlDhHbIMxYsbXcjIC5MeAha26poK9BFBCdJOQ2CG3Odl3WHHatiAtyN2Q0Axkd6h3lIkRvd/Tu01oKmBcIF1hs3C1ymZsCQO9iVGcF5lwV+omCqKp/JaCOOOeGePuOMpvV5xd99y8T2+25Efkg8kOI+73e22AiJIBGCaE6pl7NEL8taPH4WPDdN1tay6ry/s/M8ngx4M3b249dIpN00pW78V2pGu21M9vOR49jjTT2Q3aFaWXyVthyfIaii4aIpKIq6Qoq6JrolXnKu53+xNuz2DucQX7WwEu5tE+2hxYzgmQOvopatgSNmqEeiKgr9loPC35Vi93iyZ1pvcCfChDvmSYspl5pkNqlucMDVBTRFXUl9EoPSzZHj2RA47j92hXZpnajxwJLUoQ3oqjuVoi010XTWg5uuRY/YSjBfLrDthTD7UMZshqOrznRNrfcIdxdU6DQXKgUCgUCgUGiflL7PMngsy1QFesgoS+il++Gmn+6UG9lBEnDTUB68cxMsL8iI5nMsHhdFFRTKy2lHgVFREUUPcPp6feg138WeNsJXyJ53IrLFONjdzWBZIJtNnEisTZczejbJCoiqCwLYKKe0FIU6EtBc/GAAsHlBznhVkAYGItOnKZskcRbhtPBKQBVtpEQQRBcIUENE26JpoI6BQ+OMS24X5LeQESxW7s2i1NuvxbPAbQBQW5BOo0w0Ogp6qLYCmia6J0oKzwnsds5bs2b8yclsM5VnF4vbtqckXVlqW3GhsxWXu1GB0S7QF8ogUA9uwAFEREoKfxIsdvx7yJ58xe2tg3YYssmI0AE/QbjhOkI0ygKqptaAu2P8KC7eHVst1r5j8k7TbYjMO1RMijxosFhsWo7TATLuItttiiCICKbRFE0ROlBbPGc4uGcn+UkixWxtIthn9632iKCMtbYr11MGGgbHQBXagCIj0+iUFs8TcUl834hm/I2ZzLVfspyO8PWq9v361rdHhhNxmXUYjl8plGGl7/ALAaBEHYOnQERA2Z4E4kuXCmEFhE7Kn8rhtS3JFsfksLGWJGcBtPjAKvP+xDE3E0VE1NelBKNAoFAoFBE3N3AOK83RbQ/cpsyx5VjjpyceyO1ubJMV01EtFFfaYb22z/AKTFR9hjqWoXeNjvMQ2Bmzy86tLl1BpGH8iax425bmgoKuiwVyOODy9S3dsmt3/Ft9tBesNwW0YDjztjxtS+TJdfnz7tP/7MuddJa7npsww7XddcLRS02JtRADYAighFPEvjtknF3I2R8hFn63tzMTefya2O2kYzL8lwzeadaJuUXaVpxwtqaEmwiH1VCEOnGXjjkPHfLF95XezwbxPyr5H+Q207QMZl3vn3Q7BDLMmu2aDt136hqK9V3IHfjDx1yDjnla/8pv50N5l5Yr5ZFbCtIxmXVePuh2DGWZNdo9EHXfqGorquhIHvhfjrM4lzLIch4hyZiyY3lCdy5YjdbYtygsywIyaeiOMSoTjQt7yFGtSRRVUVegKAQt4dQXbd5Dc7w5N1/eJkaa41KuT3ZakS5CXGR3n1Za2im40JS7Y7AVUTpqlBNdo4AyDBuSsx5B4xzJizx87L5N/sV4tJXdj56uOO/JZdbmw3AUSddUQLcPvJF1TbtCl4d8c8i4i5HynN2c/O/wBtzJ5yTf7XPtLTUl+QrjjzTySmJACDgOPOa7I6NkJKmxF2kIW3HfFi68YZpd8o4Rz48Qs993Fc8WuFrC9W5T1NW+2iSYhALSn+l1Uh9FJRVRoJb464+PCGrtcLteHskzLI5Dc3IsgkMsxFkPMMBGaBphhNrTLTbaI23qSpqqqRKqrQZtQKBQKBQKBQKBQKBQeUmOxMjuxJTYuxnwJp5o01EwNFEhVPsqLpQa0/+q+HHGGYBB/Z7diGe24+y2yziM6DcmykAraIBM25CJHQP2qJKhiWqa60Gx9quTN4t0a5x2pDDEoEcbZmx3YckUX6OMPiDgL/AGmKLQRrzLzja+HHLE1cLTIua3lx1SVgxZFqPGVtHSRTRUNz9QdrfTX6kPTXX8zm28ftrFauw9d9Zy+YjLNl9tn84jfWs3VpGm0aaz+ollub8i4bxzjf+WZpcwtNmI2mGSdBwn3pD6KrbLLACTrjpIir2wBSREJVREElTYOQmKTRjmHc345l+czuNzs97x7MIUAbukC+Qfi9+AZAHeaNtx0FFCMRXcqLu1H8hJEPEmUCgUCgUCgUCgUCgUCg0O8l2wPzh4W3ChfpWFeqfUb3MVP9F60G+NBE3LvMvGHG11x+zchQZUqbc5LDthUbYc1j5SvdlDbfIe0LrSluJBPuCKoqJ7k1xm2J3hNjzZMdey6be6KTSaVifpP3jog7zunODL4ohvW6YcAMmZeKSyrCtvKnbRWm0V3d3dFXb3AEf7vWskLZvK+S8U4/xM8y5Ckri1pBzsEE9W3ZCukRCANtwzkd0zQVMQaUi2aqqJoWgYpb/IbDTyGw41k1rveG3DKxBcYcySCkOPcHHF0Rltxtx5G3uo/pSO2epimm4kSglqgUCgUCgUCgUCgUCg0E8pLrbrX5rcPTp8luPDhs2Epj7piDbILepepOESogiiLuJS9E60G+suXEt8R+fPfbiwYrZvyZL5i20002KkZmZKiCIoiqqquiJQaD+RnK8XlfA+K8xigMOxvZ9MZgFvJBfg22STDEoxNB2ETfuIV12qq9aDO/PF5lv/yIDcEXFygHEBVRFUA7SEWi/RNyar/Ggsvn4bttyHh3Ir9FkTeObbd3yvseMjgIRI7EdVsnBIURx1hp5GfxJNpqi/YJz5AwDx6l4ezyByCI3HC7XsvUS7Srpc50VPlq2jbzKNyHO53lVsQFsS36iiIuqUE1UCgUCgUCgUCgUCgUER3Pxh4IvdxlXe94cxc7tOcV6ZPnSZkqQ64XqpOPPkS9E0Tr0TolBcZ3APFVzx+Jidys8mbjEHYkWzybrdXoYC1p2x7Jy1BRDRNoqmifSgoJvjFwPcIsCDMwqG7BtbJx7dEVySjDAOuK64oNo6goRmWpnpuLpqvRKCuyPx74ey8bYOUYw3dxs8Fq1WtJsqY92IbGuwA3Pr169T/Ium5V0Sgy2fhOK3bFUwi82tm64qkdqIttuW6cBNMIPb3lIVwyIFESEyJSQkQtdetBguL+M3B+G3SDeLBigNS7Y/8AMtzcmbPnRY0rXVH2o0uQ6yDoqmoOC3uFeoqi0Es0CgUCgUCgUCgUCgUCgUCgUCgUCgUH/9k="
                  alt=""
                />
              </div>
              یونیک لایف
            </div>
          </div>
          <div className="border-2 border-slate-200 h-auto w-full mt-10 rounded-xl text-xs p-3 font-semibold">
            <div> فیلتر بر اساس رنگ</div>
            <hr className="my-4" />
            <div className="flex flex-wrap mx-2">
              <div className="border-2 border-slate-100 p-1 w-fit rounded-xl">
                <div className="w-6 h-6 bg-blue-600 rounded-full"></div>
              </div>
              <div className="border-2 border-slate-100 p-1 w-fit rounded-xl">
                <div className="w-6 h-6 bg-green-500 rounded-full"></div>
              </div>
              <div className="border-2 border-slate-100 p-1 w-fit rounded-xl">
                <div className="w-6 h-6 bg-white rounded-full"></div>
              </div>
              <div className="border-2 border-slate-100 p-1 w-fit rounded-xl">
                <div className="w-6 h-6 bg-yellow-400 rounded-full"></div>
              </div>
              <div className="border-2 border-slate-100 p-1 w-fit rounded-xl">
                <div className="w-6 h-6 bg-red-600 rounded-full"></div>
              </div>
              <div className="border-2 border-slate-100 p-1 w-fit rounded-xl">
                <div className="w-6 h-6 bg-stone-500 rounded-full"></div>
              </div>
              <div className="border-2 border-slate-100 p-1 w-fit rounded-xl">
                <div className="w-6 h-6 bg-gray-300 rounded-full"></div>
              </div>
            </div>
          </div>
          <div className="border-2 border-slate-200 h-auto w-full mt-10 rounded-xl text-xs p-3 font-semibold">
            <div> فیلتر بر اساس سایز</div>
            <hr className="my-4" />
            <div className="mx-2">
              <div className="flex gap-2 p-1">
                <input type="checkbox" />
                <div>۵۱</div>
              </div>
              <div className="flex gap-2 p-1">
                <input type="checkbox" />
                <div>۵۲</div>
              </div>
              <div className="flex gap-2 p-1">
                <input type="checkbox" />
                <div>۵۸</div>
              </div>
            </div>
          </div>
          <div className="border-2 border-slate-200 h-auto w-full mt-10 rounded-xl text-xs p-3 font-semibold">
            <div> میانگین رتبه </div>
            <hr className="my-4" />
            <div className="mx-2 p-1">
              <div>
                {" "}
                <FontAwesomeIcon
                  className="text-yellow-500"
                  icon={faStar}
                />{" "}
                <span>۵</span>
                <span className="mx-2">(۲)</span> <hr className="my-4" />
              </div>
              <div>
                {" "}
                <FontAwesomeIcon
                  className="text-yellow-500"
                  icon={faStar}
                />{" "}
                <span>۴</span>
                <span className="mx-2">(۱)</span> <hr className="my-4" />
              </div>
              <div>
                {" "}
                <FontAwesomeIcon
                  className="text-yellow-500"
                  icon={faStar}
                />{" "}
                <span>۳</span>
                <span className="mx-2">(۱)</span>
              </div>
            </div>
          </div>
        </div>
        <div className="sm:mx-12">
          <div>
            <div className="text-sm font-bold">فروشگاه</div>
            <div className="bg-black h-1 w-full my-4"></div>
          </div>
          <div className="grid lg:grid-cols-4 sm:grid-cols-2 gap-4 my-6">
            {products &&
              products.map((product) => (
                <div className="text-sm">
                  <div className="flex">
                    <div
                      key={product.id}
                      className=" bg-gray-50 border-2 border-slate-200 w-full sm:w-64 rounded-lg"
                    >
                      <Link to={`/products/${product.id}`}>
                        <div>
                          {" "}
                          <div className="flex justify-between">
                            <div className="bg-red-600 w-10 h-10 text-white rounded-full text-center p-2 text-xs">
                              <span>% 50</span>
                            </div>
                            <div className="p-2 bg-yellow-500 w-fit text-white rounded-s-full rounded-tl-full">
                              <span>فروش ویژه</span>
                            </div>
                          </div>
                          <div className="mx-8">
                            <img
                              className="rounded-xl cursor-pointer bg-white"
                              src={product.image}
                              alt=""
                            />
                          </div>
                          <div className="m-2">
                            <div className="text-xs font-medium">
                              <span className="text-blue-600">
                                {product.price}
                              </span>{" "}
                              تومان
                            </div>
                            <div className="text-sm font-bold my-4">
                              {product.name}
                            </div>
                            <div className="flex gap-4 text-xs mx-2">
                              <div className="border-2 border-slate-500 rounded-full p-1 text-center mt-2 cursor-pointer">
                                <FontAwesomeIcon icon={faCartShopping} />
                              </div>
                              <div className="border-2 border-slate-500 rounded-full p-1 text-center mt-2 cursor-pointer">
                                <FontAwesomeIcon icon={faArrowsLeftRight} />
                              </div>
                              <div className="border-2 border-slate-500 rounded-full p-1 text-center mt-2 cursor-pointer">
                                <FontAwesomeIcon icon={faHeart} />
                              </div>
                            </div>
                          </div>
                        </div>
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};
export default Products;
