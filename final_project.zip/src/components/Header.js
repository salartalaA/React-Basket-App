import { faCartShopping } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useSelector } from "react-redux";
import { NavLink } from "react-router-dom";

const Header = () => {
  const { cart } = useSelector((state) => state.shoppingCart);
  return (
    <div className="bg-blue-600 h-16 p-4">
      <div className="container flex justify-between">
        <div>
          <NavLink to="/" className="text-white">
            خانه
          </NavLink>
        </div>
        <div>
          <NavLink to="/products" className="text-white">
            فروشگاه
          </NavLink>
          <NavLink to="/cart">
            <FontAwesomeIcon
              className="mx-12 text-white"
              icon={faCartShopping}
            />
            <span className="bg-black p-2 text-white rounded-2xl">
              {cart.length}
            </span>
          </NavLink>
        </div>
      </div>
    </div>
  );
};
export default Header;
