const Footer = () => {
  return (
    <div className="w-full h-fit bg-footer mt-4 text-sm font-semibold leading-8">
      <div className="container pt-4 grid grid-cols-1 sm:grid-cols-3 md:grid-cols-4 text-white px-6">
        <div>
          <ul>
            <li className="text-yellow-300">دسترسی سریع</li>
            <li>تماس با ما</li>
            <li>وبلاگ</li>
            <li>شورتکد</li>
            <li>پیگیری سفارش</li>
            <li>فروشگاه</li>
          </ul>
        </div>
        <div>
          <ul>
            <li className="text-yellow-300">خدمات مشتریان</li>
            <li>سوالات متداول </li>
            <li>رویه بازگردانی کالا</li>
            <li>حریم خصوصی</li>
            <li>تماس با ما </li>
          </ul>
        </div>
        <div>
          <div className="text-yellow-300">درباره قهوه 28</div>
          <div>
            <p className="max-w-72">
              قهوه 28 یک فروشگاه تخصصی قهوه و تجهیزات قهوه ست، قهوه‌ ات را به
              صورت آنلاین سفارش بده، فروشگاه ما در غرب اهواز محله کیانپارس هست،
              هر هفته برشت میکنیم که قهوه همیشه تازه باشه، سپس با توجه به ابزار
              دم آوری که انتخاب کردید، به آدرسی که درج کردید به چندین روش حمل
              مختلف به سراسر ایران ارسال می‌کنیم.
            </p>
          </div>
        </div>
        <div>
          <div className="text-yellow-300">تماس با ما</div>
          <p>
            آدرس: اهواز، کیان پارس بین خیابان مهر و آبان غربی جنب پوشاک زاگرس
          </p>
          <div>تلفن: 09169778006</div>
          <div className="bg-black p-2 rounded-xl w-fit">
            <div>Niarashid.mehdi@gmail.com</div>
          </div>
        </div>
      </div>
      <div className="my-2">
        <hr />
      </div>
      <div className="text-center text-white p-4">
        کلیه حقوق مادی و معنوی برای این سایت محفوظ می باشد و هرگونه کپی برداری
        شامل پیگرد قانونی می باشد.
      </div>
    </div>
  );
};
export default Footer;
